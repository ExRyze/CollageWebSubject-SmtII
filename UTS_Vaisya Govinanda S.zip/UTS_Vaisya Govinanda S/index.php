<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
</head>
<body>
  <header style="display: flex;border-bottom: solid 2px black;">
    <h3>Buku</h3>
    <nav style="display: flex;margin-left: auto;gap: 1rem;align-items: center;">
      <a href="inpBuku.php">Input data buku</a>
      <a href="buku.php">Read data buku</a>
    </nav>
  </header>
  <main>
    <h1>Welcome</h1>
  </main>
  <footer>
    <p>Created by exryze</p>
  </footer>
</body>
</html>